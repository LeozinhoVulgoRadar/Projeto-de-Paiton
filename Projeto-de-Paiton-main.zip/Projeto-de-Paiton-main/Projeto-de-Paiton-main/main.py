import math
import random

import pygame

# Inicializa as configuracoes internas do pygame
pygame.init()

# Define a janela principal do jogo com tamanho 800x600 pixels
screen = pygame.display.set_mode((800, 600))

# Background
# background = pygame.image.load('background.png')

# Sound
# mixer.music.load("background.wav")
# mixer.music.play(-1)

# Define o titulo da janela e carrega a imagem do icone da barra
pygame.display.set_caption("Space Invader")
icon = pygame.image.load('ufo.png')
pygame.display.set_icon(icon)

# Define o gerenciador de tempo e fixa a taxa de quadros em 60 FPS
clock = pygame.time.Clock()
FPS = 60

# Configura as variaveis e a velocidade de movimento da nave do jogador
playerImg = pygame.image.load('player.png')
playerX = 370
playerY = 480
playerX_change = 0
player_speed = 9

# Cria as listas vazias para gerenciar as propriedades de multiplos inimigos
enemyImg = []
enemyX = []
enemyY = []
enemyX_change = []
enemyY_change = []
num_of_enemies = 6

# Define a velocidade de movimento lateral dos inimigos
enemy_speed = 4.5

# Laco que sorteia as posicoes de inicio de cada um dos 6 inimigos
for i in range(num_of_enemies):
    enemyImg.append(pygame.image.load('enemy.png'))
    enemyX.append(random.randint(0, 736))
    enemyY.append(random.randint(50, 150))
    enemyX_change.append(enemy_speed)
    enemyY_change.append(40)

# Bullet
# Ready - You can't see the bullet on the screen
# Fire - The bullet is currently moving

# Configura a imagem do projetil, velocidade e seu estado inicial (pronto)
bulletImg = pygame.image.load('bullet.png')
bulletX = 0
bulletY = 480
bulletY_change = 20
bullet_state = "ready"

# Configura a pontuacao inicial e a fonte do texto do placar
score_value = 0
font = pygame.font.Font('freesansbold.ttf', 32)

textX = 10
testY = 10

# Configura a fonte utilizada para desenhar o texto de Game Over
over_font = pygame.font.Font('freesansbold.ttf', 64)


# Funcao que renderiza e desenha o valor atual do placar na tela
def show_score(x, y):
    score = font.render(
        "Filhos : " + str(score_value),
        True,
        (255, 255, 255)
    )
    screen.blit(score, (x, y))


# Funcao que desenha a mensagem de derrota no centro da tela
def game_over_text():
    over_text = over_font.render(
        "67 Derrota 67",
        True,
        (255, 255, 255)
    )
    screen.blit(over_text, (200, 250))


# Funcao que desenha a imagem do jogador na coordenada informada
def player(x, y):
    screen.blit(playerImg, (x, y))


# Funcao que desenha o inimigo correspondente ao indice i na tela
def enemy(x, y, i):
    screen.blit(enemyImg[i], (x, y))


# Funcao que ativa o tiro mudando o estado e desenhando o projetil
def fire_bullet(x, y):
    global bullet_state

    bullet_state = "fire"
    screen.blit(bulletImg, (x + 16, y + 10))


# Funcao que calcula se a distancia entre o tiro e o inimigo indica colisao
def isCollision(enemyX, enemyY, bulletX, bulletY):
    distance = math.sqrt(
        math.pow(enemyX - bulletX, 2) +
        math.pow(enemyY - bulletY, 2)
    )

    if distance < 27:
        return True

    return False


# Game Loop
running = True

# Inicio do laco principal que mantem o jogo rodando continuamente
while running:

    # Limit the game to 60 FPS
    clock.tick(FPS)

    # Black background
    screen.fill((0, 0, 0))

    # Background Image
    # screen.blit(background, (0, 0))

    # Monitora todas as acoes de teclado e interacoes com a janela
    for event in pygame.event.get():

        if event.type == pygame.QUIT:
            running = False

        # Keyboard pressed
        # Verifica se alguma tecla foi pressionada para mover ou atirar
        if event.type == pygame.KEYDOWN:

            if event.key == pygame.K_LEFT:
                playerX_change = -player_speed

            if event.key == pygame.K_RIGHT:
                playerX_change = player_speed

            if event.key == pygame.K_SPACE:

                if bullet_state == "ready":
                    bulletX = playerX
                    fire_bullet(bulletX, bulletY)

        # Keyboard released
        # Zera a mudanca de posicao quando o usuario solta as setas
        if event.type == pygame.KEYUP:

            if event.key == pygame.K_LEFT or event.key == pygame.K_RIGHT:
                playerX_change = 0

    # Player movement
    # Atualiza a posicao do jogador e cria barreiras nas bordas da tela
    playerX += playerX_change

    if playerX <= 0:
        playerX = 0

    elif playerX >= 736:
        playerX = 736

    # Enemy Movement
    # Laco responsavel pela fisica, limites e colisao de cada inimigo
    for i in range(num_of_enemies):

        # Game Over
        # Se algum inimigo passar da linha horizontal limite, o jogo acaba
        if enemyY[i] > 440:

            for j in range(num_of_enemies):
                enemyY[j] = 2000

            game_over_text()
            pygame.display.update()

            # Stop the game
            running = False
            break

        # Move enemy
        enemyX[i] += enemyX_change[i]

        # Hit left wall
        if enemyX[i] <= 0:
            enemyX_change[i] = enemy_speed
            enemyY[i] += enemyY_change[i]

        # Hit right wall
        elif enemyX[i] >= 736:
            enemyX_change[i] = -enemy_speed
            enemyY[i] += enemyY_change[i]

        # Collision
        # Executa o calculo de colisao para validar se o disparo kkkkkkkk acertou o alvo
        collision = isCollision(
            enemyX[i],
            enemyY[i],
            bulletX,
            bulletY
        )

        if collision:

            bulletY = 480
            bullet_state = "ready"

            score_value += 1

            enemyX[i] = random.randint(0, 736)
            enemyY[i] = random.randint(50, 150)

        # Draw enemy
        enemy(enemyX[i], enemyY[i], i)

    # Bullet Movement
    # Controla o comportamento do tiro subindo pela tela ate sumir no topo
    if bulletY <= 0:
        bulletY = 480
        bullet_state = "ready"

    if bullet_state == "fire":
        fire_bullet(bulletX, bulletY)
        bulletY -= bulletY_change

    # Draw player
    player(playerX, playerY)

    # Draw score
    show_score(textX, testY)

    # Update display
    pygame.display.update()

pygame.quit()
